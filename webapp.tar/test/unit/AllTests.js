sap.ui.define([
	"ns/MOCKSERVER_MODULE/test/unit/controller/MOCKSERVER_View1.controller"
], function () {
	"use strict";
});
